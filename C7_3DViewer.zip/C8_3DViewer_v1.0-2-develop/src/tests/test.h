#ifndef SRC_TESTS_TEST_H_
#define SRC_TESTS_TEST_H_

#include <check.h>
#include "../c_sources/3d_viewer.h"

Suite *test_view(void);

#endif  //  SRC_TESTS_TEST_H_