#include "viewer.h"

viewer::viewer(QWidget *parent) : QOpenGLWidget{parent} {}
