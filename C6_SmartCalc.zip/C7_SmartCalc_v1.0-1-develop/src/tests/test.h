#ifndef SRC_TESTS_TEST_H_
#define SRC_TESTS_TEST_H_

#include <check.h>
#include "../c_source/s21_smartCalc.h"

Suite *test_calc(void);

#endif  //  SRC_TESTS_TEST_H_